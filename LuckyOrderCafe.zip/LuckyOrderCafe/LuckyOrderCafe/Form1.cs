using System.Xml.Linq;

namespace LuckyOrderCafe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                if (textBox1.Text == "")
                {
                    MessageBox.Show("fadlan magac soo geli");
                    return;
                }

                int quantity = int.Parse(textBox2.Text);
                if (quantity <= 0)
                {
                    MessageBox.Show("Fadlan geli tiro ka bilaabanta 1 ama ka badan!");
                    return;
                }

                double unitPrice = 0.00;
                string drinkName = "";


                if (radioButton1.Checked)
                {
                    unitPrice = 1.00;
                    drinkName = "Tea";
                }
                else if (radioButton3.Checked)
                {
                    unitPrice = 2.00;
                    drinkName = "Coffee";
                }
                else if (radioButton2.Checked)
                {
                    unitPrice = 3.00;
                    drinkName = "Juice";
                }
                else
                {
                    MessageBox.Show("Fadlan dooro nooca cabitaanka!");
                    return;
                }

                listBox1.Items.Clear();

                Random random = new Random();
                bool lucky = false;

                for (int i = 1; i <= quantity; i++)
                {
                    int luckyNumber = random.Next(1, 51);

                    if (luckyNumber == 7 || luckyNumber == 17)
                    {
                        lucky = true;
                    }

                    listBox1.Items.Add(
                        i + ") " + textBox1.Text +
                        " - " + drinkName +
                        " - Lucky: " + luckyNumber +
                        " - $" + unitPrice.ToString("0.00"));
                }

                double total = unitPrice * quantity;

                if (checkBox1.Checked)
                {
                    total = total - (total * 0.10);
                    //lucky = true;
                }

                label5.Text = "Total Price: $" + total.ToString("0.00");

                if (lucky)
                {
                    label6.Text = "You got a Free Cookie!";
                }
                else
                {
                    label6.Text = "No prize this time.";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Fadlan geli quantity tiro sax ah!");
            }

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();

            textBox2.Clear();

            listBox1.Items.Clear();

            label5.Text = "";

            label6.Text = "";

            checkBox1.Checked = false;

            radioButton1.Checked = false;
            radioButton3.Checked = false;
            radioButton2.Checked = false;
        }
    }
}
